// JavaScript Document  

      // calendar script for browsers without input="date" support
        var i = document.createElement("input");
        i.setAttribute("type", "date");
        if (i.type == "text") {
          $(function () {
            $("#datepicker").datepicker();
          });
        }
    // script to clone form and clear previous data
        var _counter = 0;
            function Add() {
                _counter++;
        var oClone = document.getElementById("template").cloneNode(true);
        oClone.id += (_counter + "");
        document.getElementById("placeholder").appendChild(oClone);
        var inputs = oClone.getElementsByTagName('input');
        for (var i=0, iLen=inputs.length; 
        i<iLen; i++) {
        inputs[i].value = '';
        }}
